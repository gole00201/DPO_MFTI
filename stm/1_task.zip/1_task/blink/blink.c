/**
 * @file blink.c
 * @author Volkov Egor (gole00201@gmail.com)
 * @brief
 * @version 0.1
 * @date 2025-01-12
 * @copyright Copyright (c) 2025
 */

#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/cm3/dwt.h>

// Выпендриваемся и пишем self-documented код)00))
typedef enum {
    ERROR_OK = 0,
    ERROR_DWT_INIT,
} Error_t;


// Сетапимся
static void
gpio_setup(void){
    rcc_periph_clock_enable(RCC_GPIOC);
    gpio_set_mode(GPIOC, GPIO_MODE_OUTPUT_2_MHZ,
                  GPIO_CNF_OUTPUT_PUSHPULL, GPIO13);
}

static Error_t
dwt_setup(void){
    dwt_enable_cycle_counter();
    // Проверяем что работает
    __asm volatile ("nop");
    __asm volatile ("nop");
    if (dwt_read_cycle_counter()){
        return ERROR_OK;
    } else {
        return ERROR_DWT_INIT;
    }
}

// Ждем
static void
dwt_delay_ms(uint32_t milliseconds){
    uint32_t initial_ticks = dwt_read_cycle_counter();
    uint32_t ms_count_tics = milliseconds * (rcc_ahb_frequency / 1000);
    while ((dwt_read_cycle_counter() - initial_ticks) < ms_count_tics);
}

int
main(void){
    gpio_setup();
    // Хендлим
    if(dwt_setup()){
        return 0;
    }
    // Светим
    while(1){
        gpio_toggle(GPIOC, GPIO13);
        dwt_delay_ms(200);
    }
    return 0;
}