#ifndef GPIO_INIT_H
#define GPIO_INIT_H
#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>

void
gpio_setup(void);

#endif